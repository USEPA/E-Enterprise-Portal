<?php
$function = 'validate';
include("serviceValidate.php");
?>
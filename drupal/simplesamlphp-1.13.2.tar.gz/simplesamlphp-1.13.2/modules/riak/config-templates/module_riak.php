<?php
/*
 * The configuration of the riak Store module
 *
 */

$config = array (
	/*
	 * This module has the following config options and defaults.
	 *
	 * 'path' => 'riak-php-client/riak.php',
	 * 'host' => 'localhost',
	 * 'port' => 8098,
	 * 'bucket' => 'SimpleSAMLphp',
	 */
);

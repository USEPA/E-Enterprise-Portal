<?php
/* 
 * Configuration 
 * 
 */

$config = array (

	'application' => 'simplesamlphp',
	'baseurl' => 'https://translation.rnd.feide.no/simplesaml',
	'key' => '_e7224d54cda84434e25ef087e5c22c1fa5f6ae87cc',
	'secret' => '_0e29f782d295bc9782112981f654f1db58174d19d7',

);

?>
